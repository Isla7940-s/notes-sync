const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const cookieParser = require('cookie-parser');
const multer = require('multer');
const { v4: uuidv4 } = require('uuid');

const app = express();
const PORT = 3000;
const DB = {
    POSTS: path.join(__dirname, 'db/posts.json'),
    USERS: path.join(__dirname, 'db/users.json'),
    SESSIONS: path.join(__dirname, 'db/sessions.json')
};
const AI_API_URL = 'https://open.bigmodel.cn/api/paas/v4/chat/completions';
const AI_API_KEY = '9ba4398c6bff4ab08a7909a20992278f.14q0QQzyArWSKgOd';
const AI_MODEL = 'glm-4-flash';
const AI_COMMENT_AUTHOR = 'AI评论员'; // 为AI评论创建一个用户标识

// 初始化数据库文件
async function initDB() {
    try {
        await fs.access(DB.POSTS);
    } catch {
        await fs.writeFile(DB.POSTS, '[]');
    }
    try {
        await fs.access(DB.USERS);
    } catch {
        await fs.writeFile(DB.USERS, JSON.stringify([
            { username: 'userA', password: 'passA', avatar: '/avatars/userA.png' },
            { username: 'userB', password: 'passB', avatar: '/avatars/userB.png' }
        ]));
    }
    try {
        await fs.access(DB.SESSIONS);
    } catch {
        await fs.writeFile(DB.SESSIONS, '{}');
    }
}

// 中间件配置
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

// 会话管理中间件
const sessionMiddleware = async (req, res, next) => {
    const sessions = JSON.parse(await fs.readFile(DB.SESSIONS));
    const sessionId = req.cookies.sessionId;

    if (sessionId && sessions[sessionId]) {
        req.user = sessions[sessionId];
        next();
    } else {
        res.redirect('/login');
    }
};

// 页面路由
app.get('/', (req, res) => res.redirect('/login'));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public/pages/login.html')));
app.get('/home', sessionMiddleware, (req, res) => res.sendFile(path.join(__dirname, 'public/pages/home.html')));
app.get('/post', sessionMiddleware, (req, res) => res.sendFile(path.join(__dirname, 'public/pages/post.html'))); // 新增 post 页面路由
app.get('/detail/:id', sessionMiddleware, (req, res) => res.sendFile(path.join(__dirname, 'public/pages/detail.html')));

// API路由
const apiRouter = express.Router();
apiRouter.use(sessionMiddleware);

// 用户认证API
app.post('/api/login', async (req, res) => {
    try {
        const users = JSON.parse(await fs.readFile(DB.USERS));
        const user = users.find(u => u.username === req.body.username && u.password === req.body.password);

        if (user) {
            const sessionId = uuidv4();
            const sessions = JSON.parse(await fs.readFile(DB.SESSIONS));
            sessions[sessionId] = { username: user.username };

            await fs.writeFile(DB.SESSIONS, JSON.stringify(sessions));
            res.cookie('sessionId', sessionId, { httpOnly: true, maxAge: 86400000 })
                .json({ username: user.username });
        } else {
            res.status(401).json({ error: 'Invalid credentials' });
        }
    } catch (err) {
        res.status(500).json({ error: 'Server error' });
    }
});

// AI 评论生成函数
async function generateAiComment(postContent) {
    try {
        const response = await fetch(AI_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${AI_API_KEY}` // 注意 API Key 的格式可能需要调整
            },
            body: JSON.stringify({
                model: AI_MODEL,
                messages: [
                    {
                        role: 'system',
                        content: '你是一个友善且有趣的QQ空间评论员。请为以下帖子内容生成一条简短、积极且相关的评论。'
                    },
                    {
                        role: 'user',
                        content: postContent
                    }
                ]
            })
        });

        if (!response.ok) {
            console.error('AI 评论 API 请求失败:', response.status, response.statusText);
            return null; // 请求失败返回 null
        }

        const data = await response.json();
        const aiCommentContent = data.choices && data.choices[0].message.content.trim(); // 根据实际API响应结构提取评论

        if (aiCommentContent) {
            return {
                content: aiCommentContent,
                author: AI_COMMENT_AUTHOR,
                timestamp: new Date().toISOString()
            };
        } else {
            console.warn('AI 评论内容为空或解析失败');
            return null; // 评论内容为空或解析失败返回 null
        }

    } catch (error) {
        console.error('生成 AI 评论时出错:', error);
        return null; // 发生错误返回 null
    }
}


// 帖子相关API
apiRouter.get('/posts', async (req, res) => {
    const posts = JSON.parse(await fs.readFile(DB.POSTS));
    res.json(posts);
});

apiRouter.post('/posts', async (req, res) => {
    const posts = JSON.parse(await fs.readFile(DB.POSTS));
    const newPost = {
        ...req.body,
        id: Date.now(),
        author: req.user.username,
        likes: 0,
        comments: [],
        timestamp: new Date().toISOString()
    };

    // 生成 AI 评论
    const aiComment = await generateAiComment(req.body.content);
    if (aiComment) {
        newPost.comments.push(aiComment); // 将 AI 评论添加到新帖子的评论列表中
    }

    posts.push(newPost);
    await fs.writeFile(DB.POSTS, JSON.stringify(posts));
    res.json(newPost);
});

apiRouter.post('/posts/:id/comments', async (req, res) => {
    const posts = JSON.parse(await fs.readFile(DB.POSTS));
    const post = posts.find(p => p.id === parseInt(req.params.id));
    const newComment = {
        ...req.body,
        id: Date.now(),
        author: req.user.username,
        timestamp: new Date().toISOString()
    };
    post.comments.push(newComment);
    await fs.writeFile(DB.POSTS, JSON.stringify(posts));
    res.json(newComment);
});

apiRouter.put('/posts/:id/like', async (req, res) => {
    const posts = JSON.parse(await fs.readFile(DB.POSTS));
    const post = posts.find(p => p.id === parseInt(req.params.id));
    post.likes++;
    await fs.writeFile(DB.POSTS, JSON.stringify(posts));
    res.json(post);
});

app.use('/api', apiRouter);

// 启动服务器
initDB().then(() => {
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
});