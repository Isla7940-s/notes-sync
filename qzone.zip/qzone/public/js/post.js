async function createPost() {
    const content = document.getElementById('postContent').value;
    if (!content) return;

    const response = await fetch('/api/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
    });

    if (response.ok) {
        document.getElementById('postContent').value = '';
        alert('发布成功!');
        window.location.href = '/home'; // 发布成功后跳转回主页
    } else {
        alert('发布失败');
    }
}