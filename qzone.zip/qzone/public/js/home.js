document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch('/api/posts');
        const posts = await response.json();
        renderPosts(posts);
    } catch (err) {
        console.error('加载失败:', err);
    }
});


function renderPosts(posts) {
    const container = document.getElementById('postsContainer');
    container.innerHTML = posts.map(post => `
        <div class="post-card">
            <div class="post-header">
                <img src="/avatars/${post.author}.png" class="post-avatar">
                <div>
                    <div class="post-author">${post.author}</div>
                    <div class="post-time">${new Date(post.timestamp).toLocaleString()}</div>
                </div>
            </div>
            <div class="post-content">${post.content}</div>
            <div class="post-actions">
                <button class="like-btn" onclick="likePost(${post.id})">
                    ❤️ ${post.likes}
                </button>
                <button class="comment-btn" onclick="window.location.href='/detail/${post.id}'">💬 评论</button>
            </div>
        </div>
    `).join('');
}

async function likePost(postId) {
    await fetch(`/api/posts/${postId}/like`, { method: 'PUT' });
    loadPosts();
}

async function loadPosts() {
    const response = await fetch('/api/posts');
    const posts = await response.json();
    renderPosts(posts);
}