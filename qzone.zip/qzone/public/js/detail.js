let currentPostId = window.location.pathname.split('/').pop();

document.addEventListener('DOMContentLoaded', async () => {
    try {
        const response = await fetch(`/api/posts/${currentPostId}`);
        const post = await response.json();
        renderPostDetail(post);
    } catch (err) {
        console.error('加载失败:', err);
    }
});

function renderPostDetail(post) {
    const detailContent = document.querySelector('.detail-content');
    detailContent.innerHTML = `
        <div class="post-card">
            <div class="post-header">
                <img src="/avatars/${post.author}.png" class="post-avatar">
                <div>
                    <div class="post-author">${post.author}</div>
                    <div class="post-time">${new Date(post.timestamp).toLocaleString()}</div>
                </div>
            </div>
            <div class="post-content">${post.content}</div>
            <div class="post-stats">
                ❤️ ${post.likes} 点赞 · 💬 ${post.comments.length} 评论
            </div>
        </div>
    `;
    renderComments(post.comments);
}

function renderComments(comments) {
    const list = document.getElementById('commentsList');
    list.innerHTML = comments.map(comment => `
        <div class="comment-item">
            <div class="comment-header">
                <img src="/avatars/${comment.author}.png" class="comment-avatar">
                <div>
                    <div class="comment-author">${comment.author}</div>
                    <div class="comment-time">${new Date(comment.timestamp).toLocaleString()}</div>
                </div>
            </div>
            <div class="comment-content">${comment.content}</div>
        </div>
    `).join('');
    document.getElementById('commentsCount').textContent = comments.length;
}

async function submitComment() {
    const content = document.getElementById('commentInput').value;
    if (!content) return;

    const response = await fetch(`/api/posts/${currentPostId}/comments`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ content })
    });

    if (response.ok) {
        document.getElementById('commentInput').value = '';
        loadPostDetail();
    }
}

function exitDetail() {
    window.location.href = '/home';
}

async function loadPostDetail() {
    const response = await fetch(`/api/posts/${currentPostId}`);
    const post = await response.json();
    renderPostDetail(post);
}