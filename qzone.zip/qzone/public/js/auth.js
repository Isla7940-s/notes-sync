async function login() {
    const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            username: document.getElementById('username').value,
            password: document.getElementById('password').value
        })
    });

    if (response.ok) {
        window.location.href = '/home';
    } else {
        alert('登录失败');
    }
}

function logout() {
    document.cookie = 'sessionId=; Max-Age=0; path=/';
    window.location.href = '/login';
}

function checkAuth() {
    if (!document.cookie.includes('sessionId') && !window.location.pathname.includes('/login')) {
        window.location.href = '/login';
    }
}

// 页面加载时检查认证
checkAuth();